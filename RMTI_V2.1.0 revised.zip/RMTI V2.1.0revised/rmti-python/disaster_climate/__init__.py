"""RMTI disaster/climate application."""
